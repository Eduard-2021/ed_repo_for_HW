//
//  GameScene.swift
//  gameSnake
//
//  Created by Eduard on 17.03.2021.
//

import SpriteKit
import GameplayKit

struct CollisionCategory {
    static let Snake: UInt32 = 0x1 << 0
    static let SnakeHead: UInt32 = 0x1 << 1
    static let Apple: UInt32 = 0x1 << 2
    static let EdgeBody: UInt32 = 0x1 << 3
    //Битовые маски для кнопок управления, чтобы змея под ними не проезжала. Создание яблока в этой области исключено
    static let counterClockwiseButton: UInt32 = 0x1 << 4
    static let clockwiseButton: UInt32 = 0x1 << 5
}

class GameScene: SKScene {
    
    var snake : Snake?
    var gameActive = true // переменная для контроля состояния игры (активна/закончилась)
    
      
    override func didMove(to view: SKView) {
        
        physicsWorld.gravity = CGVector(dx: 0, dy: 0 )
        physicsBody?.allowsRotation=false
        anchorPoint=CGPoint.zero
        view.showsPhysics = true
        
        //Кнопки управление вынесены в отдельный классы
        let counterClockwiseButton = CounterClockwiseButton(position: CGPoint(x: view.scene!.frame.minX + 40, y: view.scene!.frame.minY+40))
        addChild(counterClockwiseButton)
        
        let clockwiseButton = ClockwiseButton(position: CGPoint(x: view.scene!.frame.maxX - 90, y: view.scene!.frame.minY+40))
        addChild(clockwiseButton)
        
        createApple()
        //Отдельная функция для создания головы змеи
        createSnake()
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsWorld.contactDelegate = self
        
        physicsBody?.categoryBitMask = CollisionCategory.EdgeBody
        physicsBody?.collisionBitMask = CollisionCategory.Snake | CollisionCategory.SnakeHead
    }

    func createApple(){
        var randX:CGFloat = 0
        var randY:CGFloat = 0
        //Не допущение создания яблока в области кнопок управления
        repeat {
            randX = CGFloat(arc4random_uniform(UInt32(view!.scene!.frame.maxX-10)))
            randY = CGFloat(arc4random_uniform(UInt32(view!.scene!.frame.maxY-10)))
        }
        while randY < view!.scene!.frame.minY+75
        let apple = Apple(position: CGPoint(x: randX, y: randY))
        //Присвоение Ноду яблока имени для возможности его удаления по имени в конце игры
        apple.name = "Apple"
        addChild(apple)
    }
    
    
    func createSnake() {
        //Создание головы
        let snakeHead = SnakeHead(atPoint: CGPoint(x: view!.scene!.frame.midX, y: view!.scene!.frame.midY))
        addChild(snakeHead)
        
        // и помещение ее в массив тела змеи
        snake = Snake(atPoint: CGPoint(x: view!.scene!.frame.midX, y: view!.scene!.frame.midY))
        snake!.body.append(snakeHead)
    
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchLocation = touch.location(in: self)
            guard let touchesNode = self.atPoint(touchLocation) as? SKShapeNode, touchesNode.name == "counterClockwiseButton" || touchesNode.name == "ButtonRestart"  else {
                return
            }
           
            if touchesNode.name == "counterClockwiseButton" {
                touchesNode.fillColor = .lightGray
                snake!.moveCounterClockwise()
            }
            else if touchesNode.name == "clockwiseButton" {
                touchesNode.fillColor = .lightGray
                snake!.moveClockwise()
            }
            //Добавление реакции на нажатие на кнопку рестарта игры
            else if touchesNode.name == "ButtonRestart" {
                restart()
        }
    }
}
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchLocation = touch.location(in: self)
            guard let touchesNode = self.atPoint(touchLocation) as? SKShapeNode, touchesNode.name == "counterClockwiseButton" || touchesNode.name == "clockwiseButton" else {
                return
            }
            touchesNode.fillColor = .black
        
        }

    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {

    }

   
    override func update(_ currentTime: TimeInterval) {
        //Проверка на окончание игры
        if gameActive {
            snake!.move()
        }
    }
}

extension GameScene: SKPhysicsContactDelegate {
    func didBegin(_ contact: SKPhysicsContact) {
        switch contact.bodyA.categoryBitMask {
        case CollisionCategory.Apple:
            let apple = contact.bodyA.node
            addChild((snake?.addBodyPart())!)
            apple?.removeFromParent()
            createApple()
            //Проверка на столконовение головы змеи с ее телом
        case CollisionCategory.Snake:
            display(message: "GAME OVER", positionX: frame.midX, positionY: frame.midY, fontSize: 48, color: .white)
            buttonRestart() //создание кнопки рестарта игры
            gameActive = false // перевод флага состояния игры в "Неактивная"
            
        //Проверка на столкновение головы змеи с краем экрана и кнопками управления с последующим направленим головы по часовой стрелке
        case CollisionCategory.EdgeBody:
            snake!.moveCounterClockwise()
        case CollisionCategory.counterClockwiseButton:
            snake!.moveCounterClockwise()
        case CollisionCategory.clockwiseButton:
            snake!.moveCounterClockwise()
        default:
            break
        }
    }
    
    //Функция вывода текстового сообщения на экран и создания соответствующего Нода
    func display(message: String, positionX positX: CGFloat, positionY positY: CGFloat, fontSize fSize: CGFloat, color col:UIColor) {
        let messageLabel = SKLabelNode(text: message)
        let messageX = positX
        let messageY = positY
        messageLabel.position = CGPoint(x: messageX, y: messageY)
        messageLabel.fontSize = fSize
        messageLabel.name = message
        messageLabel.color = col
        addChild(messageLabel)
        }
    
    //Создание кнопки рестарта игры
    func buttonRestart() {
        display(message: "Press to restart", positionX: frame.midX, positionY: frame.midY-50, fontSize: 28, color: .blue)
       let rondedRectPath = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: 200, height: 50), cornerRadius: 15)
       let button = SKShapeNode(path: rondedRectPath.cgPath, centered: true)
        button.fillColor = .darkGray
        button.position = CGPoint(x: scene!.frame.midX, y: scene!.frame.midY-42)
        button.name = "ButtonRestart"
        addChild(button)
    }
    
    // Рестарт игры: отчистка массивов с частями тела змеи и местами, где эти части должны пройти, а также удаление всех созданых во время игры Нодов, создание нового яблока и змеи, перевод флага игры состояния "Игра активна"
    func restart() {
        for bodySnake in snake!.body {
            bodySnake.removeFromParent()
        }
        snake!.body.removeAll()
        snake!.bodyPosition.removeAll()
        childNode(withName: "Apple")!.removeFromParent()
        childNode(withName: "ButtonRestart")!.removeFromParent()
        childNode(withName: "Press to restart")!.removeFromParent()
        childNode(withName: "GAME OVER")!.removeFromParent()
        createApple()
        createSnake()
        gameActive = true
    }
}


