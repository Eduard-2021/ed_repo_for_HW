//
//  ClockwiseButton.swift
//  gameSnake
//
//  Created by Eduard on 19.03.2021.
//

import UIKit
import SpriteKit

class ClockwiseButton : SKShapeNode {
    convenience init(position: CGPoint) {
    self.init()
        path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: 50, height: 50)).cgPath
        fillColor = UIColor.black
        strokeColor = UIColor.green
        lineWidth = 10
        self.position = position
        name = "clockwiseButton"
        
        physicsBody = SKPhysicsBody(circleOfRadius: 30.0, center:CGPoint(x:25, y:25))
        physicsBody?.categoryBitMask = CollisionCategory.clockwiseButton
    }
}

