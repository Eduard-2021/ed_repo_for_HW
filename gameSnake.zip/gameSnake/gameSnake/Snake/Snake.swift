//
//  Snake.swift
//  gameSnake
//
//  Created by Eduard on 17.03.2021.
//

import UIKit
import SpriteKit

class Snake : SKShapeNode {
    
    var body : [SnakeBodyPart] = []
    var bodyPosition : [CGPoint] = [] //массив, в котором будут хранится все координаты, через которые должны пройти все части змеи
    let moveSpeed: CGFloat = 2
    let sizeHead: CGFloat = 14 //размер головы змеи
    var angle: CGFloat = 0.0

    convenience init(atPoint point: CGPoint){
        self.init()
    }
    
    func addBodyPart() ->  SnakeBodyPart {
        //Позиция нового элемента змеи (головы)- будет добавлено и расположено в районе яблока
        let positionApple: CGPoint = CGPoint(x: body[0].position.x+sizeHead*round(cos(angle)), y: body[0].position.y+sizeHead*round(sin(angle)))
        //Создание новой головы и вставка ее в массив нодов тела змеи на первую позицию
        let newBodyPart = SnakeHead(atPoint: positionApple)
        body.insert(newBodyPart, at:0)
        //Переменные для расчета растояния, на которое будут перемещаться составляющие змеи при каждом обновлении экрана, для того чтобы заполнить в массиве bodyPosition недостающие положения головы змеи в связи с ее принудительным добавлением в массив body и принудительным добавлением ее положения, смещенного на sizeHead*round(cos(angle))/sizeHead*round(sin(angle)) пикселей в голову массива bodyPosition
        let dx = CGFloat(moveSpeed)*round(cos(angle))
        let dy = CGFloat(moveSpeed)*round(sin(angle))
        let numberPostionForOneBody = Int(round(sizeHead/moveSpeed)) //расчет количества позиций, которые находятся под одним элементом тела змеи и которые надо последовательно проходить
        var positionAdd = positionApple //переменная для вычесления и хранения координат, которые находятся под новой головой и через которые должен пройти каждые элемент змеи
        var i=0 //переменная, которая контролирует в какую позицию в массиве bodyPosition вставлять новые координаты
        while bodyPosition.count<numberPostionForOneBody*body.count+1 { //контроль размера массива bodyPosition чтобы он соответствовал размеру массива body умноженому на количество координат под каждым элементом змеи
            bodyPosition.insert(positionAdd, at: i)
            i += 1
            positionAdd = CGPoint(x: positionAdd.x-dx, y: positionAdd.y-dy)
        }
        //трансформация головы змеи именно в голову по цвету
        body[0].fillColor = .brown
        //преобразование предыдущей головы в обычное тело змеи
        body[1].fillColor = .green
        body[1].physicsBody?.categoryBitMask = CollisionCategory.Snake
        body[1].physicsBody?.collisionBitMask = 0
        body[1].physicsBody?.contactTestBitMask = 0
        //возврат нового элемента змеи для создания нода
        return newBodyPart
    }
    
    func move() {
        guard !body.isEmpty else {return}
        let head = body[0]
        moveHead(head) //смещение головы на одну позицию с добавление в голову массива bodyPosition одной новой координаты (нового элемента), соответсвенно можно переприсваивать позициям (координатам) участков змеи в массиве body новые координаты с массива bodyPosition (с тех же ячеек по номеру этого массива)
        let numberPostionForOneBody = Int(round(sizeHead/moveSpeed))
        for index in (0..<body.count) where index > 0 {
            body[index].position = bodyPosition[index*numberPostionForOneBody+1]
        }
       }
   
    func moveHead(_ head: SnakeBodyPart) {
        head.fillColor = .brown
        let dx = CGFloat(moveSpeed)*round(cos(angle))
        let dy = CGFloat(moveSpeed)*round(sin(angle))
        let nextPosition = CGPoint(x: head.position.x + dx, y: head.position.y+dy)
        head.position = nextPosition
        
        //Добавление новой вычисленной координаты положения головы змеи в первую позицию массива bodyPosition с одновременным удалением последней координаты в массиве bodyPosition
        bodyPosition.insert(nextPosition, at: 0)
        bodyPosition.remove(at: bodyPosition.count-1)
    }
    
    func moveClockwise(){
        angle += CGFloat(Double.pi / 2)
    }

    func moveCounterClockwise() {
        angle -= CGFloat(Double.pi / 2)
    }
}
