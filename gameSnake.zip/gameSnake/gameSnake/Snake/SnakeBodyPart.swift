//
//  SnakeBodyPart.swift
//  gameSnake
//
//  Created by Eduard on 17.03.2021.
//

import UIKit
import SpriteKit

class SnakeBodyPart : SKShapeNode {
    let diametr: CGFloat = 14
    init(atPoint point: CGPoint) {
        super.init()
        path = UIBezierPath(ovalIn: CGRect(x: -diametr/2, y: -diametr/2, width: diametr, height: diametr)).cgPath
        fillColor = .green
        position = point
        
        physicsBody = SKPhysicsBody(circleOfRadius: diametr/4)
        physicsBody?.categoryBitMask = CollisionCategory.Snake
        physicsBody?.collisionBitMask = 0
        
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
}
