//
//  SnakeHead.swift
//  gameSnake
//
//  Created by Eduard on 17.03.2021.
//

import UIKit

class SnakeHead : SnakeBodyPart {
    override init(atPoint point : CGPoint){
        super.init(atPoint: point)
    
        physicsBody?.categoryBitMask = CollisionCategory.SnakeHead
        
        physicsBody?.contactTestBitMask = CollisionCategory.EdgeBody | CollisionCategory.Apple | CollisionCategory.Snake | CollisionCategory.clockwiseButton | CollisionCategory.counterClockwiseButton
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
}
