//
//  apple.swift
//  gameSnake
//
//  Created by Eduard on 17.03.2021.
//

import UIKit
import SpriteKit

class Apple : SKShapeNode {
    let diametr: CGFloat = 14
    convenience init(position: CGPoint) {
    self.init()
        path = UIBezierPath(ovalIn: CGRect(x: -diametr/2, y: -diametr/2, width: diametr, height: diametr)).cgPath
        fillColor = UIColor.red
        
        self.position = position
        
        physicsBody = SKPhysicsBody(circleOfRadius: diametr/2)
        
        physicsBody?.categoryBitMask = CollisionCategory.Apple
    }
}
